# Import QA fixture
No external dependencies or credentials.