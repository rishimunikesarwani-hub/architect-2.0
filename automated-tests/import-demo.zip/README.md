# Import demo

Import this ZIP, then open index.html in Preview. Try the button, change the heading in Code, save and reopen the project. The heading should keep your edit.

This small HTML app runs inside Architect's isolated preview. It has no backend or external service calls.
